# Data Instructions

This repository does not include the raw petrographic thin-section images.

## Expected Data Root

The main script expects a dataset root with image folders and metadata spreadsheets. A typical local structure is:

```text
DATA_ROOT/
  南京大学变质岩教学薄片照片数据集/
  南京大学沉积岩教学薄片照片数据集/
  南京大学火成岩教学薄片照片数据集/
  南京大学变质岩教学薄片照片信息表.xlsx
  南京大学沉积岩教学薄片照片信息表.xlsx
  南京大学火成岩教学薄片照片信息表.xlsx
```

Use the command-line arguments `--data_root` and `--meta_dir` to point to these files.

## Redistribution

The raw images belong to the dataset owner and are not redistributed here. This repository provides source code, split files, metadata templates, and lightweight result records so that the experiments can be reproduced once data access is granted.

## Leakage Control

The provided scripts create class-disjoint train/validation/test splits. If additional crops or specimen-level metadata are added, all derived images from the same source specimen should remain in the same split.
