# DA-TWML

Domain-Aware Top-k Weighted Meta-Learning (DA-TWML) for few-shot petrographic thin-section classification.

This repository contains the code and lightweight result records used for the manuscript:

**DA-TWML: Domain-Aware Top-k Weighted Meta-Learning for Few-Shot Petrographic Thin-Section Classification**

## Repository Contents

- `src/rock_fewshot_datwml_experiments.py`  
  Main implementation for ProtoNet, Random Top-k, loss-only task scoring, score-factor ablations, and full DA-TWML.
- `scripts/`  
  Reproducible command-line entry points for 5-way 1-shot, 5-way 5-shot, and combined runs.
- `analysis/`  
  Figure-generation and result-analysis scripts used for manuscript diagnostics.
- `results/runs_acml/`  
  Lightweight CSV/JSON result summaries, split files, histories, and per-run records. Model checkpoints and raw images are not included.
- `DATA.md`  
  Dataset-access and placement instructions.

## Installation

Create a Python environment and install dependencies:

```bash
pip install -r requirements.txt
```

The experiments were developed with Python 3.12 and PyTorch. A GPU is recommended for full runs, although CPU execution is supported for small checks.

## Dataset

The experiments use the Nanjing University rock thin-section teaching dataset. The raw images are not redistributed in this repository because dataset ownership and redistribution permissions must be respected.

After obtaining access to the dataset, organize the data root so that it contains the three image folders and metadata spreadsheets described in `DATA.md`.

## Reproducing the Main Experiments

Set the dataset path first. On Windows PowerShell:

```powershell
$env:DATA_ROOT="D:\南京大学岩石教学薄片显微图像数据集"
$env:META_DIR="D:\南京大学岩石教学薄片显微图像数据集"
```

Run the 5-way 1-shot ablation:

```powershell
.\scripts\run_acml_1shot.ps1
```

Run the 5-way 5-shot ablation:

```powershell
.\scripts\run_acml_5shot.ps1
```

Run both shot settings:

```powershell
.\scripts\run_acml_all.ps1
```

The main script can also be called directly:

```bash
python src/rock_fewshot_datwml_experiments.py \
  --data_root "D:\南京大学岩石教学薄片显微图像数据集" \
  --meta_dir "D:\南京大学岩石教学薄片显微图像数据集" \
  --out_dir runs_acml \
  --experiment ablation \
  --methods protonet random_topk loss_only loss_u loss_d loss_c loss_u_d loss_u_c full \
  --ways 5 --shots 1 5 --query 5 \
  --seeds 0 1 2 \
  --epochs 30 --episodes_per_epoch 100 \
  --val_episodes 200 --test_episodes 1000 \
  --meta_batch 4 --topk 2 --image_size 84
```

## Outputs

Each run writes:

- `result_*.json`: best validation/test accuracy and run metadata.
- `history_*.csv`: epoch-level validation/test records.
- `class_splits_seed*.json`: class-disjoint train/validation/test splits.
- `all_results.csv` and `all_results_summary.csv`: collected result tables.

## Notes for Reviewers

The repository is designed to reproduce the computational workflow without redistributing raw images. If the dataset cannot be publicly redistributed, reviewers can run the scripts after obtaining dataset access from the data owner and placing the files under the expected data root.

## Citation

If you use this code, please cite the associated manuscript after publication.
